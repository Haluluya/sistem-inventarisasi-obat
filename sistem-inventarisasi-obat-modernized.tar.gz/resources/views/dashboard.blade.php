<x-app-layout>
    <x-slot name="header">
        <h1 class="h3 mb-0">
            <i class="bi bi-speedometer2 me-2"></i>
            Dashboard
        </h1>
        <small class="text-muted">Selamat datang, {{ auth()->user()->name }}!</small>
    </x-slot>

    <div class="py-4">
        <!-- Statistics Cards -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="card text-white position-relative overflow-hidden" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="card-title mb-1 fw-bold">{{ \App\Models\Obat::count() }}</h2>
                                <p class="card-text mb-0 opacity-90">Total Obat</p>
                                <small class="opacity-75">Seluruh database</small>
                            </div>
                            <div class="align-self-center">
                                <div class="bg-white bg-opacity-20 rounded-circle p-3">
                                    <i class="bi bi-capsule fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="position-absolute bottom-0 end-0 opacity-10">
                        <i class="bi bi-capsule" style="font-size: 8rem; transform: rotate(15deg);"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card text-white position-relative overflow-hidden" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="card-title mb-1 fw-bold">{{ \App\Models\Obat::where('status', 'tersedia')->count() }}</h2>
                                <p class="card-text mb-0 opacity-90">Obat Tersedia</p>
                                <small class="opacity-75">Siap distribusi</small>
                            </div>
                            <div class="align-self-center">
                                <div class="bg-white bg-opacity-20 rounded-circle p-3">
                                    <i class="bi bi-check-circle fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="position-absolute bottom-0 end-0 opacity-10">
                        <i class="bi bi-check-circle" style="font-size: 8rem; transform: rotate(15deg);"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card text-white position-relative overflow-hidden" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="card-title mb-1 fw-bold">{{ \App\Models\Obat::where('stok', '<=', 10)->count() }}</h2>
                                <p class="card-text mb-0 opacity-90">Stok Menipis</p>
                                <small class="opacity-75">Perlu restok</small>
                            </div>
                            <div class="align-self-center">
                                <div class="bg-white bg-opacity-20 rounded-circle p-3">
                                    <i class="bi bi-exclamation-triangle fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="position-absolute bottom-0 end-0 opacity-10">
                        <i class="bi bi-exclamation-triangle" style="font-size: 8rem; transform: rotate(15deg);"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card text-white position-relative overflow-hidden" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="card-title mb-1 fw-bold">{{ \App\Models\UnitDistribusi::where('status', 'aktif')->count() }}</h2>
                                <p class="card-text mb-0 opacity-90">Unit Distribusi</p>
                                <small class="opacity-75">Aktif beroperasi</small>
                            </div>
                            <div class="align-self-center">
                                <div class="bg-white bg-opacity-20 rounded-circle p-3">
                                    <i class="bi bi-building fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="position-absolute bottom-0 end-0 opacity-10">
                        <i class="bi bi-building" style="font-size: 8rem; transform: rotate(15deg);"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Recent Activities -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-clock-history me-2"></i>
                            Aktivitas Terbaru
                        </h5>
                    </div>
                    <div class="card-body">
                        @php
                            $recentActivities = \App\Models\LogAktivitas::with('user')
                                ->latest()
                                ->take(10)
                                ->get();
                        @endphp
                        
                        @if($recentActivities->count() > 0)
                            <div class="list-group list-group-flush">
                                @foreach($recentActivities as $activity)
                                <div class="list-group-item border-0 px-0">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1">{{ $activity->aktivitas }}</h6>
                                            <p class="mb-1 text-muted small">
                                                oleh {{ $activity->user->name }}
                                                @if($activity->tabel_terkait)
                                                    pada {{ $activity->tabel_terkait }}
                                                @endif
                                            </p>
                                        </div>
                                        <small class="text-muted">{{ $activity->created_at->diffForHumans() }}</small>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        @else
                            <p class="text-muted text-center py-4">Belum ada aktivitas</p>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-lightning me-2"></i>
                            Aksi Cepat
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            @if(auth()->user()->isAdmin())
                                <a href="{{ route('obat.create') }}" class="btn btn-primary">
                                    <i class="bi bi-plus-circle me-2"></i>
                                    Tambah Obat Baru
                                </a>
                                <a href="{{ route('unit-distribusi.create') }}" class="btn btn-outline-primary">
                                    <i class="bi bi-plus-circle me-2"></i>
                                    Tambah Unit Distribusi
                                </a>
                            @endif
                            <a href="{{ route('obat.index') }}" class="btn btn-outline-secondary">
                                <i class="bi bi-search me-2"></i>
                                Cari Obat
                            </a>
                            <a href="{{ route('unit-distribusi.index') }}" class="btn btn-outline-secondary">
                                <i class="bi bi-building me-2"></i>
                                Lihat Unit Distribusi
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Low Stock Alert -->
                @php
                    $lowStockItems = \App\Models\Obat::where('stok', '<=', 10)->take(5)->get();
                @endphp
                
                @if($lowStockItems->count() > 0)
                <div class="card mt-4">
                    <div class="card-header bg-warning text-dark">
                        <h6 class="card-title mb-0">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Peringatan Stok
                        </h6>
                    </div>
                    <div class="card-body">
                        @foreach($lowStockItems as $item)
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <small class="fw-bold">{{ $item->nama_obat }}</small>
                                <br>
                                <small class="text-muted">{{ $item->kode_obat }}</small>
                            </div>
                            <span class="badge bg-warning text-dark">{{ $item->stok }} {{ $item->satuan }}</span>
                        </div>
                        @if(!$loop->last)<hr class="my-2">@endif
                        @endforeach
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
