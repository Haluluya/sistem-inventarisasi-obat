<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Sistem Inventarisasi Gudang Obat') }}</title>

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Bootstrap Icons -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <!-- Alpine.js -->
        <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
        
        <!-- Modern Custom CSS -->
        <style>
            :root {
                --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
                --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
                --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
                --dark-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                --glass-bg: rgba(255, 255, 255, 0.1);
                --glass-border: rgba(255, 255, 255, 0.2);
                --shadow-light: 0 8px 32px rgba(31, 38, 135, 0.37);
                --shadow-medium: 0 15px 35px rgba(31, 38, 135, 0.2);
                --shadow-heavy: 0 25px 50px rgba(31, 38, 135, 0.25);
            }

            * {
                font-family: 'Inter', sans-serif;
            }

            body {
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                min-height: 100vh;
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                backdrop-filter: blur(20px);
                border-right: 1px solid var(--glass-border);
                position: relative;
                overflow: hidden;
            }

            .sidebar::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.05)"/><circle cx="20" cy="60" r="0.5" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="40" r="0.5" fill="rgba(255,255,255,0.05)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
                opacity: 0.3;
                pointer-events: none;
            }

            .navbar-brand {
                font-weight: 700;
                color: #fff !important;
                font-size: 1.25rem;
                letter-spacing: -0.025em;
                position: relative;
                z-index: 1;
            }

            .nav-link {
                color: rgba(255,255,255,0.85) !important;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                border-radius: 12px;
                margin: 2px 0;
                padding: 12px 16px !important;
                font-weight: 500;
                position: relative;
                overflow: hidden;
            }

            .nav-link::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                transition: left 0.5s;
            }

            .nav-link:hover::before {
                left: 100%;
            }

            .nav-link:hover, .nav-link.active {
                color: #fff !important;
                background: var(--glass-bg);
                backdrop-filter: blur(10px);
                border: 1px solid var(--glass-border);
                transform: translateX(4px);
                box-shadow: var(--shadow-light);
            }

            .nav-link.active {
                background: rgba(255,255,255,0.2);
                font-weight: 600;
            }

            .card {
                border: none;
                border-radius: 20px;
                box-shadow: var(--shadow-light);
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                background: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(20px);
                overflow: hidden;
                position: relative;
            }

            .card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: var(--primary-gradient);
                opacity: 0;
                transition: opacity 0.3s ease;
            }

            .card:hover {
                box-shadow: var(--shadow-heavy);
                transform: translateY(-8px);
                background: rgba(255, 255, 255, 0.95);
            }

            .card:hover::before {
                opacity: 1;
            }

            .card-header {
                background: rgba(255, 255, 255, 0.1) !important;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                padding: 1.5rem;
                font-weight: 600;
            }

            .btn-primary {
                background: var(--primary-gradient);
                border: none;
                border-radius: 12px;
                padding: 12px 24px;
                font-weight: 600;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                position: relative;
                overflow: hidden;
            }

            .btn-primary::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                transition: left 0.5s;
            }

            .btn-primary:hover::before {
                left: 100%;
            }

            .btn-primary:hover {
                background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
                transform: translateY(-2px);
                box-shadow: var(--shadow-medium);
            }

            .btn-outline-primary {
                border: 2px solid;
                border-image: var(--primary-gradient) 1;
                color: #667eea;
                border-radius: 12px;
                font-weight: 600;
                transition: all 0.3s ease;
            }

            .btn-outline-primary:hover {
                background: var(--primary-gradient);
                border-color: transparent;
                color: white;
                transform: translateY(-2px);
                box-shadow: var(--shadow-medium);
            }

            .table {
                border-radius: 16px;
                overflow: hidden;
                box-shadow: var(--shadow-light);
                background: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(20px);
            }

            .table th {
                background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
                border-bottom: 2px solid #dee2e6;
                font-weight: 700;
                color: #495057;
                padding: 1rem;
                font-size: 0.875rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }

            .table td {
                padding: 1rem;
                vertical-align: middle;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            }

            .table tbody tr {
                transition: all 0.2s ease;
            }

            .table tbody tr:hover {
                background: rgba(102, 126, 234, 0.05);
                transform: scale(1.01);
            }

            .badge {
                font-size: 0.75rem;
                padding: 6px 12px;
                border-radius: 20px;
                font-weight: 600;
                letter-spacing: 0.025em;
            }

            .badge.bg-success {
                background: var(--success-gradient) !important;
            }

            .badge.bg-warning {
                background: var(--warning-gradient) !important;
                color: #333 !important;
            }

            .badge.bg-danger {
                background: var(--danger-gradient) !important;
            }

            .badge.bg-secondary {
                background: var(--dark-gradient) !important;
            }

            .alert {
                border: none;
                border-radius: 16px;
                padding: 1rem 1.5rem;
                backdrop-filter: blur(20px);
                position: relative;
                overflow: hidden;
            }

            .alert::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 4px;
                height: 100%;
                background: currentColor;
            }

            .alert-success {
                background: rgba(72, 187, 120, 0.1);
                color: #2f855a;
                border-left: 4px solid #48bb78;
            }

            .alert-danger {
                background: rgba(245, 101, 101, 0.1);
                color: #c53030;
                border-left: 4px solid #f56565;
            }

            .form-control, .form-select {
                border-radius: 12px;
                border: 2px solid #e2e8f0;
                padding: 12px 16px;
                transition: all 0.3s ease;
                background: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(10px);
            }

            .form-control:focus, .form-select:focus {
                border-color: #667eea;
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
                background: rgba(255, 255, 255, 1);
            }

            .input-group-text {
                background: rgba(255, 255, 255, 0.9);
                border: 2px solid #e2e8f0;
                border-right: none;
                border-radius: 12px 0 0 12px;
            }

            .modal-content {
                border-radius: 20px;
                border: none;
                box-shadow: var(--shadow-heavy);
                backdrop-filter: blur(20px);
                background: rgba(255, 255, 255, 0.95);
            }

            .modal-header {
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                padding: 1.5rem;
            }

            .modal-body {
                padding: 1.5rem;
            }

            .modal-footer {
                border-top: 1px solid rgba(0, 0, 0, 0.05);
                padding: 1.5rem;
            }

            /* Animations */
            @keyframes slideInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            .card, .alert {
                animation: slideInUp 0.6s ease-out;
            }

            /* Responsive improvements */
            @media (max-width: 768px) {
                .sidebar {
                    position: fixed;
                    top: 0;
                    left: -100%;
                    width: 280px;
                    z-index: 1050;
                    transition: left 0.3s ease;
                }

                .sidebar.show {
                    left: 0;
                }

                .main-content {
                    margin-left: 0 !important;
                }
            }

            /* Custom scrollbar */
            ::-webkit-scrollbar {
                width: 8px;
            }

            ::-webkit-scrollbar-track {
                background: rgba(0, 0, 0, 0.05);
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb {
                background: var(--primary-gradient);
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb:hover {
                background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
            }
        </style>
    </head>
    <body class="bg-light">
        <div class="container-fluid">
            <div class="row">
                <!-- Mobile Menu Toggle -->
                <div class="d-md-none position-fixed top-0 start-0 p-3" style="z-index: 1060;">
                    <button class="btn btn-primary" type="button" onclick="toggleSidebar()">
                        <i class="bi bi-list"></i>
                    </button>
                </div>

                <!-- Sidebar -->
                <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse" id="sidebar" x-data="{ open: false }">
                    <div class="position-sticky pt-3">
                        <div class="text-center mb-4">
                            <h4 class="navbar-brand">
                                <i class="bi bi-capsule-pill"></i>
                                Inventarisasi Obat
                            </h4>
                        </div>
                        
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                                    <i class="bi bi-speedometer2 me-2"></i>
                                    Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('obat.*') ? 'active' : '' }}" href="{{ route('obat.index') }}">
                                    <i class="bi bi-capsule me-2"></i>
                                    Data Obat
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('unit-distribusi.*') ? 'active' : '' }}" href="{{ route('unit-distribusi.index') }}">
                                    <i class="bi bi-building me-2"></i>
                                    Unit Distribusi
                                </a>
                            </li>
                            @if(auth()->user()->isAdmin())
                            <li class="nav-item">
                                <a class="nav-link" href="#" @click="open = !open">
                                    <i class="bi bi-gear me-2"></i>
                                    Pengaturan
                                    <i class="bi bi-chevron-down ms-auto" :class="{ 'rotate-180': open }"></i>
                                </a>
                                <ul class="nav flex-column ms-3" x-show="open" x-transition>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">
                                            <i class="bi bi-people me-2"></i>
                                            Manajemen User
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">
                                            <i class="bi bi-clock-history me-2"></i>
                                            Log Aktivitas
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            @endif
                        </ul>
                        
                        <hr class="my-3" style="border-color: rgba(255,255,255,0.2);">
                        
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('profile.edit') }}">
                                    <i class="bi bi-person me-2"></i>
                                    Profile
                                </a>
                            </li>
                            <li class="nav-item">
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <a class="nav-link" href="#" onclick="event.preventDefault(); this.closest('form').submit();">
                                        <i class="bi bi-box-arrow-right me-2"></i>
                                        Logout
                                    </a>
                                </form>
                            </li>
                        </ul>
                    </div>
                </nav>

                <!-- Main content -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <!-- Page Heading -->
                    @if (isset($header))
                        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            {{ $header }}
                        </div>
                    @endif

                    <!-- Flash Messages -->
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert" x-data x-init="setTimeout(() => $el.remove(), 5000)">
                            <i class="bi bi-check-circle me-2"></i>
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert" x-data x-init="setTimeout(() => $el.remove(), 5000)">
                            <i class="bi bi-exclamation-circle me-2"></i>
                            {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    <!-- Page Content -->
                    {{ $slot }}
                </main>
            </div>
        </div>

        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- Mobile Menu Script -->
        <script>
            function toggleSidebar() {
                const sidebar = document.getElementById('sidebar');
                sidebar.classList.toggle('show');
            }

            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                const sidebar = document.getElementById('sidebar');
                const toggleBtn = event.target.closest('button[onclick="toggleSidebar()"]');
                
                if (!sidebar.contains(event.target) && !toggleBtn && window.innerWidth < 768) {
                    sidebar.classList.remove('show');
                }
            });
        </script>
    </body>
</html>
