<x-app-layout>
    <x-slot name="header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-0">
                    <i class="bi bi-plus-circle me-2"></i>
                    Tambah Obat Baru
                </h1>
                <small class="text-muted">Tambahkan data obat baru ke sistem inventarisasi</small>
            </div>
            <a href="{{ route('obat.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali
            </a>
        </div>
    </x-slot>

    <div class="py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="{{ route('obat.store') }}" enctype="multipart/form-data" 
                              x-data="obatForm()" @submit="validateForm">
                            @csrf
                            
                            <div class="row g-3">
                                <!-- Kode Obat -->
                                <div class="col-md-6">
                                    <label for="kode_obat" class="form-label">
                                        Kode Obat <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" 
                                           class="form-control @error('kode_obat') is-invalid @enderror" 
                                           id="kode_obat" 
                                           name="kode_obat" 
                                           value="{{ old('kode_obat') }}"
                                           x-model="form.kode_obat"
                                           @input="validateKodeObat"
                                           placeholder="Contoh: PCT001"
                                           required>
                                    @error('kode_obat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">Kode unik untuk identifikasi obat</div>
                                </div>

                                <!-- Nama Obat -->
                                <div class="col-md-6">
                                    <label for="nama_obat" class="form-label">
                                        Nama Obat <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" 
                                           class="form-control @error('nama_obat') is-invalid @enderror" 
                                           id="nama_obat" 
                                           name="nama_obat" 
                                           value="{{ old('nama_obat') }}"
                                           x-model="form.nama_obat"
                                           placeholder="Contoh: Paracetamol 500mg"
                                           required>
                                    @error('nama_obat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Kategori -->
                                <div class="col-md-6">
                                    <label for="kategori" class="form-label">
                                        Kategori <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" 
                                           class="form-control @error('kategori') is-invalid @enderror" 
                                           id="kategori" 
                                           name="kategori" 
                                           value="{{ old('kategori') }}"
                                           x-model="form.kategori"
                                           placeholder="Contoh: Analgesik"
                                           list="kategori-list"
                                           required>
                                    <datalist id="kategori-list">
                                        <option value="Analgesik">
                                        <option value="Antibiotik">
                                        <option value="Vitamin">
                                        <option value="Anti-inflamasi">
                                        <option value="Obat Batuk">
                                        <option value="Obat Demam">
                                        <option value="Suplemen">
                                    </datalist>
                                    @error('kategori')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Unit Distribusi -->
                                <div class="col-md-6">
                                    <label for="unit_distribusi_id" class="form-label">
                                        Unit Distribusi <span class="text-danger">*</span>
                                    </label>
                                    <select class="form-select @error('unit_distribusi_id') is-invalid @enderror" 
                                            id="unit_distribusi_id" 
                                            name="unit_distribusi_id"
                                            x-model="form.unit_distribusi_id"
                                            required>
                                        <option value="">Pilih Unit Distribusi</option>
                                        @foreach($unitDistribusi as $unit)
                                        <option value="{{ $unit->id }}" {{ old('unit_distribusi_id') == $unit->id ? 'selected' : '' }}>
                                            {{ $unit->nama_unit }}
                                        </option>
                                        @endforeach
                                    </select>
                                    @error('unit_distribusi_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Deskripsi -->
                                <div class="col-12">
                                    <label for="deskripsi" class="form-label">Deskripsi</label>
                                    <textarea class="form-control @error('deskripsi') is-invalid @enderror" 
                                              id="deskripsi" 
                                              name="deskripsi" 
                                              rows="3"
                                              x-model="form.deskripsi"
                                              placeholder="Deskripsi obat, kegunaan, atau informasi tambahan">{{ old('deskripsi') }}</textarea>
                                    @error('deskripsi')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Stok -->
                                <div class="col-md-4">
                                    <label for="stok" class="form-label">
                                        Stok <span class="text-danger">*</span>
                                    </label>
                                    <input type="number" 
                                           class="form-control @error('stok') is-invalid @enderror" 
                                           id="stok" 
                                           name="stok" 
                                           value="{{ old('stok') }}"
                                           x-model="form.stok"
                                           min="0"
                                           required>
                                    @error('stok')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Satuan -->
                                <div class="col-md-4">
                                    <label for="satuan" class="form-label">
                                        Satuan <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" 
                                           class="form-control @error('satuan') is-invalid @enderror" 
                                           id="satuan" 
                                           name="satuan" 
                                           value="{{ old('satuan') }}"
                                           x-model="form.satuan"
                                           placeholder="Contoh: tablet, kapsul, botol"
                                           list="satuan-list"
                                           required>
                                    <datalist id="satuan-list">
                                        <option value="tablet">
                                        <option value="kapsul">
                                        <option value="botol">
                                        <option value="strip">
                                        <option value="box">
                                        <option value="tube">
                                    </datalist>
                                    @error('satuan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Harga -->
                                <div class="col-md-4">
                                    <label for="harga" class="form-label">
                                        Harga (Rp) <span class="text-danger">*</span>
                                    </label>
                                    <input type="number" 
                                           class="form-control @error('harga') is-invalid @enderror" 
                                           id="harga" 
                                           name="harga" 
                                           value="{{ old('harga') }}"
                                           x-model="form.harga"
                                           min="0"
                                           step="0.01"
                                           required>
                                    @error('harga')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Tanggal Kadaluarsa -->
                                <div class="col-md-6">
                                    <label for="tanggal_kadaluarsa" class="form-label">Tanggal Kadaluarsa</label>
                                    <input type="date" 
                                           class="form-control @error('tanggal_kadaluarsa') is-invalid @enderror" 
                                           id="tanggal_kadaluarsa" 
                                           name="tanggal_kadaluarsa" 
                                           value="{{ old('tanggal_kadaluarsa') }}"
                                           x-model="form.tanggal_kadaluarsa"
                                           min="{{ date('Y-m-d') }}">
                                    @error('tanggal_kadaluarsa')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Status -->
                                <div class="col-md-6">
                                    <label for="status" class="form-label">
                                        Status <span class="text-danger">*</span>
                                    </label>
                                    <select class="form-select @error('status') is-invalid @enderror" 
                                            id="status" 
                                            name="status"
                                            x-model="form.status"
                                            required>
                                        <option value="">Pilih Status</option>
                                        <option value="tersedia" {{ old('status') == 'tersedia' ? 'selected' : '' }}>Tersedia</option>
                                        <option value="habis" {{ old('status') == 'habis' ? 'selected' : '' }}>Habis</option>
                                        <option value="kadaluarsa" {{ old('status') == 'kadaluarsa' ? 'selected' : '' }}>Kadaluarsa</option>
                                    </select>
                                    @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Foto Kemasan -->
                                <div class="col-12">
                                    <label for="foto_kemasan" class="form-label">Foto Kemasan</label>
                                    <input type="file" 
                                           class="form-control @error('foto_kemasan') is-invalid @enderror" 
                                           id="foto_kemasan" 
                                           name="foto_kemasan"
                                           accept="image/*"
                                           @change="previewImage">
                                    @error('foto_kemasan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">Format: JPG, PNG, GIF. Maksimal 2MB.</div>
                                    
                                    <!-- Image Preview -->
                                    <div x-show="imagePreview" class="mt-3">
                                        <img :src="imagePreview" alt="Preview" class="img-thumbnail" style="max-width: 200px;">
                                    </div>
                                </div>

                                <!-- Keterangan -->
                                <div class="col-12">
                                    <label for="keterangan" class="form-label">Keterangan</label>
                                    <textarea class="form-control @error('keterangan') is-invalid @enderror" 
                                              id="keterangan" 
                                              name="keterangan" 
                                              rows="2"
                                              x-model="form.keterangan"
                                              placeholder="Keterangan tambahan (opsional)">{{ old('keterangan') }}</textarea>
                                    @error('keterangan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <!-- Submit Buttons -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="d-flex gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-check-circle me-2"></i>
                                            Simpan Obat
                                        </button>
                                        <button type="reset" class="btn btn-outline-secondary" @click="resetForm">
                                            <i class="bi bi-arrow-clockwise me-2"></i>
                                            Reset Form
                                        </button>
                                        <a href="{{ route('obat.index') }}" class="btn btn-outline-danger">
                                            <i class="bi bi-x-circle me-2"></i>
                                            Batal
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function obatForm() {
            return {
                form: {
                    kode_obat: '',
                    nama_obat: '',
                    kategori: '',
                    unit_distribusi_id: '',
                    deskripsi: '',
                    stok: '',
                    satuan: '',
                    harga: '',
                    tanggal_kadaluarsa: '',
                    status: 'tersedia',
                    keterangan: ''
                },
                imagePreview: null,
                
                validateKodeObat() {
                    // Auto uppercase and remove spaces
                    this.form.kode_obat = this.form.kode_obat.toUpperCase().replace(/\s/g, '');
                },
                
                previewImage(event) {
                    const file = event.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            this.imagePreview = e.target.result;
                        };
                        reader.readAsDataURL(file);
                    } else {
                        this.imagePreview = null;
                    }
                },
                
                resetForm() {
                    this.form = {
                        kode_obat: '',
                        nama_obat: '',
                        kategori: '',
                        unit_distribusi_id: '',
                        deskripsi: '',
                        stok: '',
                        satuan: '',
                        harga: '',
                        tanggal_kadaluarsa: '',
                        status: 'tersedia',
                        keterangan: ''
                    };
                    this.imagePreview = null;
                },
                
                validateForm(event) {
                    // Client-side validation
                    if (!this.form.kode_obat || !this.form.nama_obat || !this.form.kategori) {
                        event.preventDefault();
                        alert('Mohon lengkapi semua field yang wajib diisi!');
                        return false;
                    }
                    
                    if (this.form.stok < 0 || this.form.harga < 0) {
                        event.preventDefault();
                        alert('Stok dan harga tidak boleh negatif!');
                        return false;
                    }
                    
                    return true;
                }
            }
        }
    </script>
</x-app-layout>

