<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Data Obat - Sistem Inventarisasi Gudang Obat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }
        .header p {
            margin: 5px 0 0 0;
            color: #666;
        }
        .info {
            margin-bottom: 20px;
        }
        .info p {
            margin: 2px 0;
            font-size: 11px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 10px;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
            text-align: center;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .status-tersedia {
            color: #28a745;
            font-weight: bold;
        }
        .status-habis {
            color: #dc3545;
            font-weight: bold;
        }
        .status-kadaluarsa {
            color: #ffc107;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>LAPORAN DATA OBAT</h1>
        <p>Sistem Inventarisasi Gudang Obat</p>
    </div>

    <div class="info">
        <p><strong>Tanggal Export:</strong> {{ date('d/m/Y H:i:s') }}</p>
        <p><strong>User:</strong> {{ auth()->user()->name }}</p>
        <p><strong>Total Data:</strong> {{ $obat->count() }} obat</p>
    </div>

    @if($obat->count() > 0)
    <table>
        <thead>
            <tr>
                <th width="8%">No</th>
                <th width="12%">Kode Obat</th>
                <th width="20%">Nama Obat</th>
                <th width="12%">Kategori</th>
                <th width="8%">Stok</th>
                <th width="8%">Satuan</th>
                <th width="12%">Harga (Rp)</th>
                <th width="10%">Status</th>
                <th width="10%">Unit Distribusi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($obat as $index => $item)
            <tr>
                <td class="text-center">{{ $index + 1 }}</td>
                <td>{{ $item->kode_obat }}</td>
                <td>{{ $item->nama_obat }}</td>
                <td>{{ $item->kategori }}</td>
                <td class="text-right">{{ number_format($item->stok, 0, ',', '.') }}</td>
                <td>{{ $item->satuan }}</td>
                <td class="text-right">{{ number_format($item->harga, 0, ',', '.') }}</td>
                <td class="text-center">
                    <span class="status-{{ $item->status }}">
                        {{ ucfirst($item->status) }}
                    </span>
                </td>
                <td>{{ $item->unitDistribusi->nama_unit }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        <h4>Ringkasan:</h4>
        <table style="width: 50%;">
            <tr>
                <td><strong>Total Obat:</strong></td>
                <td>{{ $obat->count() }}</td>
            </tr>
            <tr>
                <td><strong>Obat Tersedia:</strong></td>
                <td>{{ $obat->where('status', 'tersedia')->count() }}</td>
            </tr>
            <tr>
                <td><strong>Obat Habis:</strong></td>
                <td>{{ $obat->where('status', 'habis')->count() }}</td>
            </tr>
            <tr>
                <td><strong>Obat Kadaluarsa:</strong></td>
                <td>{{ $obat->where('status', 'kadaluarsa')->count() }}</td>
            </tr>
            <tr>
                <td><strong>Total Nilai Stok:</strong></td>
                <td>Rp {{ number_format($obat->sum(function($item) { return $item->stok * $item->harga; }), 0, ',', '.') }}</td>
            </tr>
        </table>
    </div>
    @else
    <div style="text-align: center; margin-top: 50px;">
        <p>Tidak ada data obat untuk ditampilkan.</p>
    </div>
    @endif

    <div class="footer">
        <p>Dicetak pada: {{ date('d/m/Y H:i:s') }} | Sistem Inventarisasi Gudang Obat</p>
    </div>
</body>
</html>

