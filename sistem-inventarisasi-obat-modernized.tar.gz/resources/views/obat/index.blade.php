<x-app-layout>
    <x-slot name="header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-0">
                    <i class="bi bi-capsule me-2"></i>
                    Data Obat
                </h1>
                <small class="text-muted">Kelola data obat dalam sistem inventarisasi</small>
            </div>
            @if(auth()->user()->isAdmin())
            <a href="{{ route('obat.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Obat
            </a>
            @endif
        </div>
    </x-slot>

    <div class="py-4">
        <!-- Search and Filter -->
        <div class="card mb-4" x-data="{ showFilters: false }">
            <div class="card-body">
                <form method="GET" action="{{ route('obat.index') }}">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="bi bi-search"></i>
                                </span>
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Cari nama obat, kode, atau kategori..." 
                                       value="{{ request('search') }}">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search me-1"></i>
                                Cari
                            </button>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-outline-secondary w-100" 
                                    @click="showFilters = !showFilters">
                                <i class="bi bi-funnel me-1"></i>
                                Filter
                            </button>
                        </div>
                        <div class="col-md-2">
                            <a href="{{ route('obat.index') }}" class="btn btn-outline-danger w-100">
                                <i class="bi bi-x-circle me-1"></i>
                                Reset
                            </a>
                        </div>
                        <div class="col-md-2">
                            <div class="dropdown">
                                <button class="btn btn-outline-success dropdown-toggle w-100" type="button" 
                                        data-bs-toggle="dropdown">
                                    <i class="bi bi-download me-1"></i>
                                    Export
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="{{ route('obat.export.pdf', request()->query()) }}"><i class="bi bi-file-pdf me-2"></i>PDF</a></li>
                                    <li><a class="dropdown-item" href="{{ route('obat.export.excel', request()->query()) }}"><i class="bi bi-file-excel me-2"></i>Excel</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Advanced Filters -->
                    <div x-show="showFilters" x-transition class="row g-3 mt-3 pt-3 border-top">
                        <div class="col-md-3">
                            <label class="form-label">Kategori</label>
                            <select name="kategori" class="form-select">
                                <option value="">Semua Kategori</option>
                                @foreach($categories as $category)
                                <option value="{{ $category }}" {{ request('kategori') == $category ? 'selected' : '' }}>
                                    {{ $category }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">Semua Status</option>
                                <option value="tersedia" {{ request('status') == 'tersedia' ? 'selected' : '' }}>Tersedia</option>
                                <option value="habis" {{ request('status') == 'habis' ? 'selected' : '' }}>Habis</option>
                                <option value="kadaluarsa" {{ request('status') == 'kadaluarsa' ? 'selected' : '' }}>Kadaluarsa</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Urutkan</label>
                            <select name="sort_by" class="form-select">
                                <option value="nama_obat" {{ request('sort_by') == 'nama_obat' ? 'selected' : '' }}>Nama Obat</option>
                                <option value="kode_obat" {{ request('sort_by') == 'kode_obat' ? 'selected' : '' }}>Kode Obat</option>
                                <option value="kategori" {{ request('sort_by') == 'kategori' ? 'selected' : '' }}>Kategori</option>
                                <option value="stok" {{ request('sort_by') == 'stok' ? 'selected' : '' }}>Stok</option>
                                <option value="harga" {{ request('sort_by') == 'harga' ? 'selected' : '' }}>Harga</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Urutan</label>
                            <select name="sort_order" class="form-select">
                                <option value="asc" {{ request('sort_order') == 'asc' ? 'selected' : '' }}>A-Z / Kecil-Besar</option>
                                <option value="desc" {{ request('sort_order') == 'desc' ? 'selected' : '' }}>Z-A / Besar-Kecil</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Data Table -->
        <div class="card">
            <div class="card-body">
                @if($obat->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Foto</th>
                                <th>Kode Obat</th>
                                <th>Nama Obat</th>
                                <th>Kategori</th>
                                <th>Stok</th>
                                <th>Harga</th>
                                <th>Status</th>
                                <th>Unit Distribusi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($obat as $item)
                            <tr>
                                <td>
                                    @if($item->foto_kemasan)
                                    <img src="{{ asset('storage/' . $item->foto_kemasan) }}" 
                                         alt="Foto {{ $item->nama_obat }}" 
                                         class="rounded" 
                                         style="width: 50px; height: 50px; object-fit: cover;">
                                    @else
                                    <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                         style="width: 50px; height: 50px;">
                                        <i class="bi bi-image text-muted"></i>
                                    </div>
                                    @endif
                                </td>
                                <td>
                                    <span class="fw-bold">{{ $item->kode_obat }}</span>
                                </td>
                                <td>
                                    <div>
                                        <span class="fw-bold">{{ $item->nama_obat }}</span>
                                        @if($item->deskripsi)
                                        <br>
                                        <small class="text-muted">{{ Str::limit($item->deskripsi, 50) }}</small>
                                        @endif
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">{{ $item->kategori }}</span>
                                </td>
                                <td>
                                    <span class="fw-bold {{ $item->stok <= 10 ? 'text-warning' : '' }}">
                                        {{ $item->stok }} {{ $item->satuan }}
                                    </span>
                                    @if($item->stok <= 10)
                                    <br>
                                    <small class="text-warning">
                                        <i class="bi bi-exclamation-triangle"></i>
                                        Stok Menipis
                                    </small>
                                    @endif
                                </td>
                                <td>Rp {{ number_format($item->harga, 0, ',', '.') }}</td>
                                <td>
                                    @if($item->status == 'tersedia')
                                    <span class="badge bg-success">Tersedia</span>
                                    @elseif($item->status == 'habis')
                                    <span class="badge bg-danger">Habis</span>
                                    @else
                                    <span class="badge bg-warning text-dark">Kadaluarsa</span>
                                    @endif
                                </td>
                                <td>
                                    <small>{{ $item->unitDistribusi->nama_unit }}</small>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('obat.show', $item) }}" 
                                           class="btn btn-sm btn-outline-info" 
                                           title="Lihat Detail">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        @if(auth()->user()->isAdmin())
                                        <a href="{{ route('obat.edit', $item) }}" 
                                           class="btn btn-sm btn-outline-warning" 
                                           title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger" 
                                                title="Hapus"
                                                onclick="confirmDelete('{{ $item->id }}', '{{ $item->nama_obat }}')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <div>
                        <small class="text-muted">
                            Menampilkan {{ $obat->firstItem() ?? 0 }} - {{ $obat->lastItem() ?? 0 }} 
                            dari {{ $obat->total() }} data
                        </small>
                    </div>
                    <div>
                        {{ $obat->appends(request()->query())->links() }}
                    </div>
                </div>
                @else
                <div class="text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <h5 class="mt-3">Tidak ada data obat</h5>
                    <p class="text-muted">
                        @if(request()->hasAny(['search', 'kategori', 'status']))
                        Tidak ditemukan obat yang sesuai dengan kriteria pencarian.
                        @else
                        Belum ada data obat yang ditambahkan ke sistem.
                        @endif
                    </p>
                    @if(auth()->user()->isAdmin())
                    <a href="{{ route('obat.create') }}" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>
                        Tambah Obat Pertama
                    </a>
                    @endif
                </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Hapus</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin menghapus obat <strong id="obatName"></strong>?</p>
                    <p class="text-danger small">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        Tindakan ini tidak dapat dibatalkan.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" style="display: inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(id, name) {
            document.getElementById('obatName').textContent = name;
            document.getElementById('deleteForm').action = `/obat/${id}`;
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }
    </script>
</x-app-layout>

