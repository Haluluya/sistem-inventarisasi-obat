<x-app-layout>
    <x-slot name="header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-0">
                    <i class="bi bi-plus-circle me-2"></i>
                    Tambah Unit Distribusi
                </h1>
                <small class="text-muted">Tambahkan unit distribusi baru ke sistem</small>
            </div>
            <a href="{{ route('unit-distribusi.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali
            </a>
        </div>
    </x-slot>

    <div class="py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="{{ route('unit-distribusi.store') }}" 
                              x-data="unitForm()" @submit="validateForm">
                            @csrf
                            
                            <div class="row g-3">
                                <!-- Nama Unit -->
                                <div class="col-12">
                                    <label for="nama_unit" class="form-label">
                                        Nama Unit Distribusi <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" 
                                           class="form-control @error('nama_unit') is-invalid @enderror" 
                                           id="nama_unit" 
                                           name="nama_unit" 
                                           value="{{ old('nama_unit') }}"
                                           x-model="form.nama_unit"
                                           placeholder="Contoh: Apotek Sehat Sentosa"
                                           required>
                                    @error('nama_unit')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Alamat -->
                                <div class="col-12">
                                    <label for="alamat" class="form-label">
                                        Alamat <span class="text-danger">*</span>
                                    </label>
                                    <textarea class="form-control @error('alamat') is-invalid @enderror" 
                                              id="alamat" 
                                              name="alamat" 
                                              rows="3"
                                              x-model="form.alamat"
                                              placeholder="Alamat lengkap unit distribusi"
                                              required>{{ old('alamat') }}</textarea>
                                    @error('alamat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Kontak -->
                                <div class="col-md-6">
                                    <label for="kontak" class="form-label">Nomor Kontak</label>
                                    <input type="text" 
                                           class="form-control @error('kontak') is-invalid @enderror" 
                                           id="kontak" 
                                           name="kontak" 
                                           value="{{ old('kontak') }}"
                                           x-model="form.kontak"
                                           placeholder="Contoh: 021-1234567 atau 08123456789">
                                    @error('kontak')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" 
                                           class="form-control @error('email') is-invalid @enderror" 
                                           id="email" 
                                           name="email" 
                                           value="{{ old('email') }}"
                                           x-model="form.email"
                                           placeholder="Contoh: apotek@example.com">
                                    @error('email')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Status -->
                                <div class="col-md-6">
                                    <label for="status" class="form-label">
                                        Status <span class="text-danger">*</span>
                                    </label>
                                    <select class="form-select @error('status') is-invalid @enderror" 
                                            id="status" 
                                            name="status"
                                            x-model="form.status"
                                            required>
                                        <option value="">Pilih Status</option>
                                        <option value="aktif" {{ old('status') == 'aktif' ? 'selected' : '' }}>Aktif</option>
                                        <option value="nonaktif" {{ old('status') == 'nonaktif' ? 'selected' : '' }}>Non-aktif</option>
                                    </select>
                                    @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Keterangan -->
                                <div class="col-12">
                                    <label for="keterangan" class="form-label">Keterangan</label>
                                    <textarea class="form-control @error('keterangan') is-invalid @enderror" 
                                              id="keterangan" 
                                              name="keterangan" 
                                              rows="3"
                                              x-model="form.keterangan"
                                              placeholder="Keterangan tambahan tentang unit distribusi (opsional)">{{ old('keterangan') }}</textarea>
                                    @error('keterangan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <!-- Submit Buttons -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="d-flex gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-check-circle me-2"></i>
                                            Simpan Unit Distribusi
                                        </button>
                                        <button type="reset" class="btn btn-outline-secondary" @click="resetForm">
                                            <i class="bi bi-arrow-clockwise me-2"></i>
                                            Reset Form
                                        </button>
                                        <a href="{{ route('unit-distribusi.index') }}" class="btn btn-outline-danger">
                                            <i class="bi bi-x-circle me-2"></i>
                                            Batal
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function unitForm() {
            return {
                form: {
                    nama_unit: '',
                    alamat: '',
                    kontak: '',
                    email: '',
                    status: 'aktif',
                    keterangan: ''
                },
                
                resetForm() {
                    this.form = {
                        nama_unit: '',
                        alamat: '',
                        kontak: '',
                        email: '',
                        status: 'aktif',
                        keterangan: ''
                    };
                },
                
                validateForm(event) {
                    // Client-side validation
                    if (!this.form.nama_unit || !this.form.alamat || !this.form.status) {
                        event.preventDefault();
                        alert('Mohon lengkapi semua field yang wajib diisi!');
                        return false;
                    }
                    
                    // Email validation if provided
                    if (this.form.email && !this.isValidEmail(this.form.email)) {
                        event.preventDefault();
                        alert('Format email tidak valid!');
                        return false;
                    }
                    
                    return true;
                },
                
                isValidEmail(email) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    return emailRegex.test(email);
                }
            }
        }
    </script>
</x-app-layout>

