<x-app-layout>
    <x-slot name="header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-0">
                    <i class="bi bi-building me-2"></i>
                    Unit Distribusi
                </h1>
                <small class="text-muted">Kelola data unit distribusi obat</small>
            </div>
            @if(auth()->user()->isAdmin())
            <a href="{{ route('unit-distribusi.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Unit Distribusi
            </a>
            @endif
        </div>
    </x-slot>

    <div class="py-4">
        <!-- Search and Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="{{ route('unit-distribusi.index') }}">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="bi bi-search"></i>
                                </span>
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Cari nama unit, alamat, atau kontak..." 
                                       value="{{ request('search') }}">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <select name="status" class="form-select">
                                <option value="">Semua Status</option>
                                <option value="aktif" {{ request('status') == 'aktif' ? 'selected' : '' }}>Aktif</option>
                                <option value="nonaktif" {{ request('status') == 'nonaktif' ? 'selected' : '' }}>Non-aktif</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="sort_by" class="form-select">
                                <option value="nama_unit" {{ request('sort_by') == 'nama_unit' ? 'selected' : '' }}>Nama Unit</option>
                                <option value="created_at" {{ request('sort_by') == 'created_at' ? 'selected' : '' }}>Tanggal Dibuat</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search me-1"></i>
                                Cari
                            </button>
                        </div>
                        <div class="col-md-2">
                            <a href="{{ route('unit-distribusi.index') }}" class="btn btn-outline-danger w-100">
                                <i class="bi bi-x-circle me-1"></i>
                                Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Data Cards -->
        @if($unitDistribusi->count() > 0)
        <div class="row g-4">
            @foreach($unitDistribusi as $unit)
            <div class="col-lg-6 col-xl-4">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="card-title mb-0">{{ $unit->nama_unit }}</h5>
                            @if($unit->status == 'aktif')
                            <span class="badge bg-success">Aktif</span>
                            @else
                            <span class="badge bg-secondary">Non-aktif</span>
                            @endif
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex align-items-start mb-2">
                                <i class="bi bi-geo-alt text-muted me-2 mt-1"></i>
                                <small class="text-muted">{{ $unit->alamat }}</small>
                            </div>
                            
                            @if($unit->kontak)
                            <div class="d-flex align-items-center mb-2">
                                <i class="bi bi-telephone text-muted me-2"></i>
                                <small class="text-muted">{{ $unit->kontak }}</small>
                            </div>
                            @endif
                            
                            @if($unit->email)
                            <div class="d-flex align-items-center mb-2">
                                <i class="bi bi-envelope text-muted me-2"></i>
                                <small class="text-muted">{{ $unit->email }}</small>
                            </div>
                            @endif
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <span class="text-muted small">Total Obat:</span>
                                <span class="fw-bold text-primary">{{ $unit->obat_count }}</span>
                            </div>
                            <small class="text-muted">
                                Dibuat {{ $unit->created_at->diffForHumans() }}
                            </small>
                        </div>
                        
                        @if($unit->keterangan)
                        <p class="card-text small text-muted mb-3">
                            {{ Str::limit($unit->keterangan, 100) }}
                        </p>
                        @endif
                    </div>
                    
                    <div class="card-footer bg-transparent">
                        <div class="btn-group w-100" role="group">
                            <a href="{{ route('unit-distribusi.show', $unit) }}" 
                               class="btn btn-outline-info btn-sm">
                                <i class="bi bi-eye me-1"></i>
                                Detail
                            </a>
                            @if(auth()->user()->isAdmin())
                            <a href="{{ route('unit-distribusi.edit', $unit) }}" 
                               class="btn btn-outline-warning btn-sm">
                                <i class="bi bi-pencil me-1"></i>
                                Edit
                            </a>
                            <button type="button" 
                                    class="btn btn-outline-danger btn-sm" 
                                    onclick="confirmDelete('{{ $unit->id }}', '{{ $unit->nama_unit }}', {{ $unit->obat_count }})">
                                <i class="bi bi-trash me-1"></i>
                                Hapus
                            </button>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-between align-items-center mt-4">
            <div>
                <small class="text-muted">
                    Menampilkan {{ $unitDistribusi->firstItem() ?? 0 }} - {{ $unitDistribusi->lastItem() ?? 0 }} 
                    dari {{ $unitDistribusi->total() }} data
                </small>
            </div>
            <div>
                {{ $unitDistribusi->appends(request()->query())->links() }}
            </div>
        </div>
        @else
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="bi bi-building display-1 text-muted"></i>
                <h5 class="mt-3">Tidak ada data unit distribusi</h5>
                <p class="text-muted">
                    @if(request()->hasAny(['search', 'status']))
                    Tidak ditemukan unit distribusi yang sesuai dengan kriteria pencarian.
                    @else
                    Belum ada data unit distribusi yang ditambahkan ke sistem.
                    @endif
                </p>
                @if(auth()->user()->isAdmin())
                <a href="{{ route('unit-distribusi.create') }}" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-2"></i>
                    Tambah Unit Distribusi Pertama
                </a>
                @endif
            </div>
        </div>
        @endif
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Hapus</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin menghapus unit distribusi <strong id="unitName"></strong>?</p>
                    <div id="obatWarning" class="alert alert-warning" style="display: none;">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Unit distribusi ini memiliki <strong id="obatCount"></strong> obat terkait. 
                        Pastikan untuk memindahkan atau menghapus obat tersebut terlebih dahulu.
                    </div>
                    <p class="text-danger small">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        Tindakan ini tidak dapat dibatalkan.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" style="display: inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" id="deleteButton">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(id, name, obatCount) {
            document.getElementById('unitName').textContent = name;
            document.getElementById('deleteForm').action = `/unit-distribusi/${id}`;
            
            if (obatCount > 0) {
                document.getElementById('obatCount').textContent = obatCount;
                document.getElementById('obatWarning').style.display = 'block';
                document.getElementById('deleteButton').disabled = true;
                document.getElementById('deleteButton').textContent = 'Tidak Dapat Dihapus';
                document.getElementById('deleteButton').className = 'btn btn-secondary';
            } else {
                document.getElementById('obatWarning').style.display = 'none';
                document.getElementById('deleteButton').disabled = false;
                document.getElementById('deleteButton').textContent = 'Hapus';
                document.getElementById('deleteButton').className = 'btn btn-danger';
            }
            
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }
    </script>
</x-app-layout>

