<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreObatRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->isAdmin();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'kode_obat' => [
                'required',
                'string',
                'max:50',
                'unique:obat,kode_obat',
                'regex:/^[A-Z0-9]+$/'
            ],
            'nama_obat' => [
                'required',
                'string',
                'max:255',
                'min:3'
            ],
            'kategori' => [
                'required',
                'string',
                'max:100'
            ],
            'deskripsi' => [
                'nullable',
                'string',
                'max:1000'
            ],
            'stok' => [
                'required',
                'integer',
                'min:0',
                'max:999999'
            ],
            'harga' => [
                'required',
                'numeric',
                'min:0',
                'max:999999999.99'
            ],
            'satuan' => [
                'required',
                'string',
                'max:50'
            ],
            'tanggal_kadaluarsa' => [
                'nullable',
                'date',
                'after:today'
            ],
            'foto_kemasan' => [
                'nullable',
                'image',
                'mimes:jpeg,png,jpg,gif',
                'max:2048'
            ],
            'unit_distribusi_id' => [
                'required',
                'exists:unit_distribusi,id'
            ],
            'status' => [
                'required',
                'in:tersedia,habis,kadaluarsa'
            ],
            'keterangan' => [
                'nullable',
                'string',
                'max:500'
            ]
        ];
    }

    /**
     * Get custom error messages for validation rules.
     */
    public function messages(): array
    {
        return [
            'kode_obat.required' => 'Kode obat wajib diisi.',
            'kode_obat.unique' => 'Kode obat sudah digunakan.',
            'kode_obat.regex' => 'Kode obat hanya boleh mengandung huruf kapital dan angka.',
            'nama_obat.required' => 'Nama obat wajib diisi.',
            'nama_obat.min' => 'Nama obat minimal 3 karakter.',
            'kategori.required' => 'Kategori obat wajib diisi.',
            'stok.required' => 'Stok obat wajib diisi.',
            'stok.min' => 'Stok tidak boleh negatif.',
            'stok.max' => 'Stok maksimal 999,999.',
            'harga.required' => 'Harga obat wajib diisi.',
            'harga.min' => 'Harga tidak boleh negatif.',
            'harga.max' => 'Harga terlalu besar.',
            'satuan.required' => 'Satuan obat wajib diisi.',
            'tanggal_kadaluarsa.after' => 'Tanggal kadaluarsa harus setelah hari ini.',
            'foto_kemasan.image' => 'File harus berupa gambar.',
            'foto_kemasan.mimes' => 'Format gambar harus JPEG, PNG, JPG, atau GIF.',
            'foto_kemasan.max' => 'Ukuran gambar maksimal 2MB.',
            'unit_distribusi_id.required' => 'Unit distribusi wajib dipilih.',
            'unit_distribusi_id.exists' => 'Unit distribusi tidak valid.',
            'status.required' => 'Status obat wajib dipilih.',
            'status.in' => 'Status obat tidak valid.'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'kode_obat' => 'kode obat',
            'nama_obat' => 'nama obat',
            'kategori' => 'kategori',
            'deskripsi' => 'deskripsi',
            'stok' => 'stok',
            'harga' => 'harga',
            'satuan' => 'satuan',
            'tanggal_kadaluarsa' => 'tanggal kadaluarsa',
            'foto_kemasan' => 'foto kemasan',
            'unit_distribusi_id' => 'unit distribusi',
            'status' => 'status',
            'keterangan' => 'keterangan'
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'kode_obat' => strtoupper(str_replace(' ', '', $this->kode_obat))
        ]);
    }
}
