<?php

namespace App\Http\Controllers;

use App\Models\UnitDistribusi;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;

class UnitDistribusiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin')->except(['index', 'show']);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = UnitDistribusi::withCount('obat');

        // Search functionality
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_unit', 'like', "%{$search}%")
                  ->orWhere('alamat', 'like', "%{$search}%")
                  ->orWhere('kontak', 'like', "%{$search}%");
            });
        }

        // Filter by status
        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }

        // Sort functionality
        $sortBy = $request->get('sort_by', 'nama_unit');
        $sortOrder = $request->get('sort_order', 'asc');
        $query->orderBy($sortBy, $sortOrder);

        $unitDistribusi = $query->paginate(10);

        return view('unit-distribusi.index', compact('unitDistribusi'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('unit-distribusi.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_unit' => 'required|max:255',
            'alamat' => 'required',
            'kontak' => 'nullable|max:255',
            'email' => 'nullable|email|max:255',
            'status' => 'required|in:aktif,nonaktif',
            'keterangan' => 'nullable'
        ]);

        $unitDistribusi = UnitDistribusi::create($validated);

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Menambah unit distribusi baru',
            'tabel_terkait' => 'unit_distribusi',
            'id_terkait' => $unitDistribusi->id,
            'data_baru' => $unitDistribusi->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('unit-distribusi.index')->with('success', 'Unit distribusi berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(UnitDistribusi $unitDistribusi)
    {
        $unitDistribusi->load(['obat' => function($query) {
            $query->orderBy('nama_obat');
        }]);
        
        return view('unit-distribusi.show', compact('unitDistribusi'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UnitDistribusi $unitDistribusi)
    {
        return view('unit-distribusi.edit', compact('unitDistribusi'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, UnitDistribusi $unitDistribusi)
    {
        $validated = $request->validate([
            'nama_unit' => 'required|max:255',
            'alamat' => 'required',
            'kontak' => 'nullable|max:255',
            'email' => 'nullable|email|max:255',
            'status' => 'required|in:aktif,nonaktif',
            'keterangan' => 'nullable'
        ]);

        $oldData = $unitDistribusi->toArray();
        $unitDistribusi->update($validated);

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Mengupdate unit distribusi',
            'tabel_terkait' => 'unit_distribusi',
            'id_terkait' => $unitDistribusi->id,
            'data_lama' => $oldData,
            'data_baru' => $unitDistribusi->fresh()->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('unit-distribusi.index')->with('success', 'Unit distribusi berhasil diupdate.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, UnitDistribusi $unitDistribusi)
    {
        // Check if unit has related obat
        if ($unitDistribusi->obat()->count() > 0) {
            return redirect()->route('unit-distribusi.index')
                ->with('error', 'Unit distribusi tidak dapat dihapus karena masih memiliki obat terkait.');
        }

        $oldData = $unitDistribusi->toArray();
        $unitDistribusi->delete();

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Menghapus unit distribusi',
            'tabel_terkait' => 'unit_distribusi',
            'id_terkait' => $unitDistribusi->id,
            'data_lama' => $oldData,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('unit-distribusi.index')->with('success', 'Unit distribusi berhasil dihapus.');
    }
}
