<?php

namespace App\Http\Controllers;

use App\Models\Obat;
use App\Models\UnitDistribusi;
use App\Models\LogAktivitas;
use App\Http\Requests\StoreObatRequest;
use App\Http\Requests\UpdateObatRequest;
use App\Exports\ObatExport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;

class ObatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin')->except(['index', 'show']);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Obat::with('unitDistribusi');

        // Search functionality
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_obat', 'like', "%{$search}%")
                  ->orWhere('kode_obat', 'like', "%{$search}%")
                  ->orWhere('kategori', 'like', "%{$search}%");
            });
        }

        // Filter by category
        if ($request->has('kategori') && $request->kategori) {
            $query->where('kategori', $request->kategori);
        }

        // Filter by status
        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }

        // Sort functionality
        $sortBy = $request->get('sort_by', 'nama_obat');
        $sortOrder = $request->get('sort_order', 'asc');
        $query->orderBy($sortBy, $sortOrder);

        $obat = $query->paginate(10);
        $categories = Obat::distinct()->pluck('kategori');

        return view('obat.index', compact('obat', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $unitDistribusi = UnitDistribusi::where('status', 'aktif')->get();
        return view('obat.create', compact('unitDistribusi'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreObatRequest $request)
    {
        $validated = $request->validated();

        // Handle file upload
        if ($request->hasFile('foto_kemasan')) {
            $validated['foto_kemasan'] = $request->file('foto_kemasan')->store('obat', 'public');
        }

        $obat = Obat::create($validated);

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Menambah obat baru',
            'tabel_terkait' => 'obat',
            'id_terkait' => $obat->id,
            'data_baru' => $obat->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('obat.index')->with('success', 'Obat berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Obat $obat)
    {
        $obat->load('unitDistribusi');
        return view('obat.show', compact('obat'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Obat $obat)
    {
        $unitDistribusi = UnitDistribusi::where('status', 'aktif')->get();
        return view('obat.edit', compact('obat', 'unitDistribusi'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateObatRequest $request, Obat $obat)
    {
        $validated = $request->validated();
        $oldData = $obat->toArray();

        // Handle file upload
        if ($request->hasFile('foto_kemasan')) {
            // Delete old file
            if ($obat->foto_kemasan) {
                Storage::disk('public')->delete($obat->foto_kemasan);
            }
            $validated['foto_kemasan'] = $request->file('foto_kemasan')->store('obat', 'public');
        }

        $obat->update($validated);

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Mengupdate obat',
            'tabel_terkait' => 'obat',
            'id_terkait' => $obat->id,
            'data_lama' => $oldData,
            'data_baru' => $obat->fresh()->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('obat.index')->with('success', 'Obat berhasil diupdate.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, Obat $obat)
    {
        $oldData = $obat->toArray();

        // Delete file if exists
        if ($obat->foto_kemasan) {
            Storage::disk('public')->delete($obat->foto_kemasan);
        }

        $obat->delete();

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Menghapus obat',
            'tabel_terkait' => 'obat',
            'id_terkait' => $obat->id,
            'data_lama' => $oldData,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return redirect()->route('obat.index')->with('success', 'Obat berhasil dihapus.');
    }

    /**
     * Export data obat to Excel
     */
    public function exportExcel(Request $request)
    {
        $filters = $request->only(['search', 'kategori', 'status', 'sort_by', 'sort_order']);
        
        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Export data obat ke Excel',
            'tabel_terkait' => 'obat',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        $filename = 'data-obat-' . date('Y-m-d-H-i-s') . '.xlsx';
        
        return Excel::download(new ObatExport($filters), $filename);
    }

    /**
     * Export data obat to PDF
     */
    public function exportPdf(Request $request)
    {
        $query = Obat::with('unitDistribusi');

        // Apply same filters as index
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_obat', 'like', "%{$search}%")
                  ->orWhere('kode_obat', 'like', "%{$search}%")
                  ->orWhere('kategori', 'like', "%{$search}%");
            });
        }

        if ($request->has('kategori') && $request->kategori) {
            $query->where('kategori', $request->kategori);
        }

        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }

        $sortBy = $request->get('sort_by', 'nama_obat');
        $sortOrder = $request->get('sort_order', 'asc');
        $query->orderBy($sortBy, $sortOrder);

        $obat = $query->get();

        // Log activity
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => 'Export data obat ke PDF',
            'tabel_terkait' => 'obat',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        $pdf = Pdf::loadView('obat.pdf', compact('obat'));
        $filename = 'data-obat-' . date('Y-m-d-H-i-s') . '.pdf';
        
        return $pdf->download($filename);
    }
}
