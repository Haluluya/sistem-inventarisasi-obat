<?php

namespace App\Exports;

use App\Models\Obat;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ObatExport implements FromCollection, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{
    protected $filters;

    public function __construct($filters = [])
    {
        $this->filters = $filters;
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $query = Obat::with('unitDistribusi');

        // Apply filters
        if (isset($this->filters['search']) && $this->filters['search']) {
            $search = $this->filters['search'];
            $query->where(function($q) use ($search) {
                $q->where('nama_obat', 'like', "%{$search}%")
                  ->orWhere('kode_obat', 'like', "%{$search}%")
                  ->orWhere('kategori', 'like', "%{$search}%");
            });
        }

        if (isset($this->filters['kategori']) && $this->filters['kategori']) {
            $query->where('kategori', $this->filters['kategori']);
        }

        if (isset($this->filters['status']) && $this->filters['status']) {
            $query->where('status', $this->filters['status']);
        }

        $sortBy = $this->filters['sort_by'] ?? 'nama_obat';
        $sortOrder = $this->filters['sort_order'] ?? 'asc';
        $query->orderBy($sortBy, $sortOrder);

        return $query->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Kode Obat',
            'Nama Obat',
            'Kategori',
            'Deskripsi',
            'Stok',
            'Satuan',
            'Harga (Rp)',
            'Status',
            'Unit Distribusi',
            'Tanggal Kadaluarsa',
            'Keterangan',
            'Dibuat Pada'
        ];
    }

    /**
     * @param mixed $obat
     * @return array
     */
    public function map($obat): array
    {
        return [
            $obat->kode_obat,
            $obat->nama_obat,
            $obat->kategori,
            $obat->deskripsi,
            $obat->stok,
            $obat->satuan,
            number_format($obat->harga, 0, ',', '.'),
            ucfirst($obat->status),
            $obat->unitDistribusi->nama_unit,
            $obat->tanggal_kadaluarsa ? $obat->tanggal_kadaluarsa->format('d/m/Y') : '-',
            $obat->keterangan,
            $obat->created_at->format('d/m/Y H:i')
        ];
    }

    /**
     * @param Worksheet $sheet
     * @return array
     */
    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1 => ['font' => ['bold' => true]],
        ];
    }
}
