<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Obat extends Model
{
    use HasFactory;

    protected $table = 'obat';

    protected $fillable = [
        'kode_obat',
        'nama_obat',
        'kategori',
        'deskripsi',
        'stok',
        'harga',
        'satuan',
        'tanggal_kadaluarsa',
        'foto_kemasan',
        'unit_distribusi_id',
        'status',
        'keterangan'
    ];

    protected $casts = [
        'harga' => 'decimal:2',
        'tanggal_kadaluarsa' => 'date',
        'status' => 'string'
    ];

    // Relationship dengan UnitDistribusi
    public function unitDistribusi()
    {
        return $this->belongsTo(UnitDistribusi::class);
    }
}
