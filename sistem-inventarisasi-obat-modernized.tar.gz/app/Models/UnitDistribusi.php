<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UnitDistribusi extends Model
{
    use HasFactory;

    protected $table = 'unit_distribusi';

    protected $fillable = [
        'nama_unit',
        'alamat',
        'kontak',
        'email',
        'status',
        'keterangan'
    ];

    protected $casts = [
        'status' => 'string'
    ];

    // Relationship dengan Obat
    public function obat()
    {
        return $this->hasMany(Obat::class);
    }
}
