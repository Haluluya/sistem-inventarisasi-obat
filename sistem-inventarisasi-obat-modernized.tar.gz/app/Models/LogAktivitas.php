<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LogAktivitas extends Model
{
    use HasFactory;

    protected $table = 'log_aktivitas';

    protected $fillable = [
        'user_id',
        'aktivitas',
        'tabel_terkait',
        'id_terkait',
        'data_lama',
        'data_baru',
        'ip_address',
        'user_agent'
    ];

    protected $casts = [
        'data_lama' => 'array',
        'data_baru' => 'array'
    ];

    // Relationship dengan User
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
