<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\UnitDistribusi;

class UnitDistribusiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        UnitDistribusi::create([
            'nama_unit' => 'Apotek Sehat Sentosa',
            'alamat' => 'Jl. Merdeka No. 123, Jakarta Pusat',
            'kontak' => '021-12345678',
            'email' => 'apotek.sehat@email.com',
            'status' => 'aktif',
            'keterangan' => 'Apotek utama di Jakarta Pusat'
        ]);

        UnitDistribusi::create([
            'nama_unit' => 'Apotek Kimia Farma',
            'alamat' => 'Jl. Sudirman No. 456, Jakarta Selatan',
            'kontak' => '021-87654321',
            'email' => 'kimiafarma@email.com',
            'status' => 'aktif',
            'keterangan' => 'Cabang Kimia Farma Jakarta Selatan'
        ]);

        UnitDistribusi::create([
            'nama_unit' => 'Apotek Guardian',
            'alamat' => 'Jl. Thamrin No. 789, Jakarta Pusat',
            'kontak' => '021-11223344',
            'email' => 'guardian@email.com',
            'status' => 'aktif',
            'keterangan' => 'Apotek Guardian Mall Thamrin'
        ]);
    }
}
