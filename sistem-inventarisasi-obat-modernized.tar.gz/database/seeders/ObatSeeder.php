<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Obat;

class ObatSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Obat::create([
            'kode_obat' => 'PCT001',
            'nama_obat' => 'Paracetamol 500mg',
            'kategori' => 'Analgesik',
            'deskripsi' => 'Obat pereda nyeri dan penurun demam',
            'stok' => 100,
            'harga' => 5000.00,
            'satuan' => 'tablet',
            'tanggal_kadaluarsa' => '2025-12-31',
            'unit_distribusi_id' => 1,
            'status' => 'tersedia',
            'keterangan' => 'Obat bebas terbatas'
        ]);

        Obat::create([
            'kode_obat' => 'AMX001',
            'nama_obat' => 'Amoxicillin 500mg',
            'kategori' => 'Antibiotik',
            'deskripsi' => 'Antibiotik untuk infeksi bakteri',
            'stok' => 50,
            'harga' => 15000.00,
            'satuan' => 'kapsul',
            'tanggal_kadaluarsa' => '2025-10-15',
            'unit_distribusi_id' => 1,
            'status' => 'tersedia',
            'keterangan' => 'Obat keras, perlu resep dokter'
        ]);

        Obat::create([
            'kode_obat' => 'VIT001',
            'nama_obat' => 'Vitamin C 1000mg',
            'kategori' => 'Vitamin',
            'deskripsi' => 'Suplemen vitamin C untuk daya tahan tubuh',
            'stok' => 75,
            'harga' => 25000.00,
            'satuan' => 'tablet',
            'tanggal_kadaluarsa' => '2026-06-30',
            'unit_distribusi_id' => 2,
            'status' => 'tersedia',
            'keterangan' => 'Suplemen makanan'
        ]);

        Obat::create([
            'kode_obat' => 'IBU001',
            'nama_obat' => 'Ibuprofen 400mg',
            'kategori' => 'Anti-inflamasi',
            'deskripsi' => 'Obat anti-inflamasi dan pereda nyeri',
            'stok' => 30,
            'harga' => 8000.00,
            'satuan' => 'tablet',
            'tanggal_kadaluarsa' => '2025-08-20',
            'unit_distribusi_id' => 2,
            'status' => 'tersedia',
            'keterangan' => 'Obat bebas terbatas'
        ]);

        Obat::create([
            'kode_obat' => 'OBH001',
            'nama_obat' => 'OBH Combi Batuk Flu',
            'kategori' => 'Obat Batuk',
            'deskripsi' => 'Sirup obat batuk dan flu',
            'stok' => 25,
            'harga' => 12000.00,
            'satuan' => 'botol',
            'tanggal_kadaluarsa' => '2025-11-30',
            'unit_distribusi_id' => 3,
            'status' => 'tersedia',
            'keterangan' => 'Obat bebas'
        ]);
    }
}
