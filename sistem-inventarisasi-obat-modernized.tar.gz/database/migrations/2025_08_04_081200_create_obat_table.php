<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('obat', function (Blueprint $table) {
            $table->id();
            $table->string('kode_obat')->unique();
            $table->string('nama_obat');
            $table->string('kategori');
            $table->text('deskripsi')->nullable();
            $table->integer('stok')->default(0);
            $table->decimal('harga', 10, 2);
            $table->string('satuan');
            $table->date('tanggal_kadaluarsa')->nullable();
            $table->string('foto_kemasan')->nullable();
            $table->foreignId('unit_distribusi_id')->constrained('unit_distribusi')->onDelete('cascade');
            $table->enum('status', ['tersedia', 'habis', 'kadaluarsa'])->default('tersedia');
            $table->text('keterangan')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('obat');
    }
};
